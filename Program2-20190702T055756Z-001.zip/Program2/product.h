#pragma once
class Product
{
private:
	int productId;
	char name[10];
	int price;

public:
	Product();

	void setProId(int id);
	void setName(char * name);
	void setPrice(int price);

	int getProId();
	char* getName();
	int getPrice();

	void acceptProductInfo();
	int calculateBill(Product *,int);
	void displayBill();
	~Product();
};

