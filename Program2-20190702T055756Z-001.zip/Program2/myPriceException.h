#pragma once
#include"pch.h"
#include<iostream>
#include<exception>
using namespace std;
class MyPriceException : public exception
{
private :
	char errorMsg[50];

public:
	MyPriceException(const char * errorMsg);
	const char* what() const;
	~MyPriceException();
};

