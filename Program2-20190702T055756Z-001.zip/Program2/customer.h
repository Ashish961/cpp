#pragma once
class Customer
{
private:
	int custId;
	char custName[10];
	int nop;
public:
	Customer();
	int getNOP();
	void acceptCustomerInfo();
	~Customer();
};

