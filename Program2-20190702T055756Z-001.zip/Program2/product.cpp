#include "pch.h"
#include "product.h"


Product::Product()
{
	strcpy(this->name,"\0");
	this->productId = 0;
	this->price = 0;
}

void Product::setProId(int id)
{
	
	this->productId = id;
	
}

void Product::setName(char * name)
{
	strcpy(this->name, name);
}

void Product::setPrice(int price)
{
	this->price = price;
}

int Product::getProId()
{
	return this->productId;
}

char * Product::getName()
{
	return this->name;
}

int Product::getPrice()
{
	return this->price;
}

void Product::acceptProductInfo()
{
	cout << "\nEnter Product id : ";
	cin >> this->productId;
	cout << "\nEnter Product Name : ";
	cin >> this->name;
	cout << "\nEnter Price : ";
	cin >> this->price;
	if (this->price<=0)
	{
		MyPriceException ex("Exception : Price must be Positive and  price > 0");
		throw ex;
	}
}

int Product::calculateBill(Product * p,int nop)
{
	int bill = 0;
	for (int i=0;i<nop;i++)
	{
		bill = bill + p[i].getPrice();
	}
	cout << "\nTotal Bill : " << bill;
	return 0;
}

void Product::displayBill()
{
	
}


Product::~Product()
{
}
