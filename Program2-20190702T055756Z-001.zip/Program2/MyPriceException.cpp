#include "pch.h"
#include "myPriceException.h"


MyPriceException::MyPriceException(const char * errorMsg)
{
	strcpy(this->errorMsg,errorMsg);
}

const char * MyPriceException::what() const
{
	return this->errorMsg;
}


MyPriceException::~MyPriceException()
{
}
