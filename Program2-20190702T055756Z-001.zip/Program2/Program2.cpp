#include "pch.h"
#include <iostream>

int main()
{
	Customer cust;
	try {
		cust.acceptCustomerInfo();
	}
	catch (MyPriceException ex)
	{
		cout << "\n====================================================\n";
		cout << ex.what();
		cout << "\n====================================================\n";
	}

	
}