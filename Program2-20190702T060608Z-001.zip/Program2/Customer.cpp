#include "pch.h"
#include "customer.h"


Customer::Customer()
{
	this->custId = 0;
	strcpy(this->custName,"\0");
	this->nop = 0;
}

int Customer::getNOP()
{
	return this->nop;
}


void Customer::acceptCustomerInfo()
{
	cout << "\nEnter Customer Id : ";
	cin >> this->custId;
	cout << "\nEnter Customer Name : ";
	cin >> this->custName;
	cout << "\nEnter Number of products : ";
	cin >> this->nop;

	Product * p = new Product[nop];

	for (int i=0;i<nop;i++)
	{
		p[i].acceptProductInfo();
	}
	p->calculateBill(p,nop);
}


Customer::~Customer()
{
}
