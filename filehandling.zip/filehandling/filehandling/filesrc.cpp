#include"fileopehead.h"
#include<string.h>
PlacementPortal::PlacementPortal()
{
	this->PrnNumber = 0;
	strcpy(this->name, "unknown");
	this->marks = 0.0;

}

PlacementPortal::PlacementPortal(int prnNumber, const char*name, double marks)
{
	this->PrnNumber = prnNumber;
	strcpy(this->name,name);
	this->marks = marks;
}
void PlacementPortal::accept()
{
	cout << "enter the prn number:";
	cin >> this->PrnNumber;
	cout << "enter the name:";
	cin >> this->name;
	cout << "enter the marks ";
	cin >> this->marks;
}
void PlacementPortal::display()
{
	cout << "\n prn number" << this->PrnNumber;
	cout << "\n name" << this->name;
    cout << "\n marks" << this->marks;
}
