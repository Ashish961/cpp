#include<iostream>
using namespace std;
class PlacementPortal
{
private:
	int PrnNumber;
	double marks;
	char name[30];
public:
	PlacementPortal();
	PlacementPortal(int,const char*,double);
	void accept();
	void display();
	int getprnno()
	{
		return this->PrnNumber;
	}
};
