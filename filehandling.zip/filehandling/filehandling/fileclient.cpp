#include"fileopehead.h"
#include<conio.h>
#include<fstream>
using namespace std;
class fileoperation
{
public:
	static  void writeRecord()
	{
		char wish;
		fstream fs;
		PlacementPortal p;
		fs.open("ashish.dat", ios::out | ios::binary);
		do {
			p.accept();
			fs.write((char*)&p, 1 * sizeof(PlacementPortal));
			cout << " do you want to add more record:";
			cin >> wish;
		} while (wish == 'Y' || wish == 'y');
		fs.close();
	}
	static void ReadRecord()
	{
		fstream fs;
		PlacementPortal p;
		fs.open("ashish.dat", ios::in | ios::binary);
		while (fs.read((char*)&p,sizeof(PlacementPortal)));
		{
			p.display();
		}
		fs.close();
	}
	static bool SearchRecord(int prnNumber)
	{
		fstream fs;
		PlacementPortal p;
		fs.open("ashish.dat", ios::in | ios::binary);
		while (fs.read((char*)&p, 1 * sizeof(PlacementPortal)))
		{
			if (p.getprnno() == prnNumber)
			{
				p.display();
			fs.close();
			return true;
		}
	}
	fs.close();
	return false;
}
};
int main()
{
	bool res;
	int choice;
	char choice1;
	do {
		cout << "\n 1.write record\n 2.read record \n 3.search record \n 4.exit";
		cout << "enter the choice";
		cin >> choice;
		switch (choice)
		{
		case 1:fileoperation::writeRecord();
			     break;
		case 2:fileoperation::ReadRecord();
			    break;
		case 3:
			int prn;
			cout << "enter the prn number to search:";
			cin >> prn;
			res = fileoperation::SearchRecord(prn);
			if (res)
			{
				cout << "record found";

			}
			else
			{
				cout << "record not found";
			}
			break;
		case 4:
			exit(0);
		}
		cout << " do you want to continue:";
		cin >> choice1;
	} while (choice1 == 'y' || choice1 == 'Y');
	_getch();
	return 0;
}