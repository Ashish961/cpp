#pragma once
#include"pch.h"
class Prime : public OlaRide
{
public:
	Prime();
	void accept();
	float calculateFare();
	~Prime();
};

