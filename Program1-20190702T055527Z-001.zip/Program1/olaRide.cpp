#include "pch.h"
#include "olaRide.h"


OlaRide::OlaRide()
{
	strcpy(this-> source,"\0");
	strcpy(this->destination,"\0");
	this->rate_per_km = 0;
	this->distance = 0;
}

void OlaRide::setSource(char * source)
{
	strcpy(this->source, source);
	
}

void OlaRide::setDestination(char *destination)
{
	strcpy(this->destination, destination);
	
}

void OlaRide::setRate_per_km(int rate_per_km)
{
	this->rate_per_km = rate_per_km;
}

void OlaRide::setDistance(int distance)
{
	this->distance = distance;
}

char * OlaRide::getSource()
{
	return this->source;
}

char * OlaRide::getDestination()
{
	return this->destination;
}

int OlaRide::getRate_per_km()
{
	return this->rate_per_km;
}

int OlaRide::getDistance()
{
	return this->distance;
}



OlaRide::~OlaRide()
{
}
