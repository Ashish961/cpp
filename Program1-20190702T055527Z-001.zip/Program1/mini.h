#pragma once
#include"pch.h"
class Mini : public OlaRide
{
public:
	Mini();
	void accept();
	float calculateFare();
	~Mini();
};

