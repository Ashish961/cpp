#pragma once
class OlaRide
{
private:
	char source[10];
	char destination[10];
	int rate_per_km;
	int distance;
public:

	OlaRide();
	void setSource(char* source);
	void setDestination(char *);
	void setRate_per_km(int rate_per_km);
	void setDistance(int distance);

	char* getSource();
	char * getDestination();
	int getRate_per_km();
	int getDistance();
	virtual float calculateFare() = 0;
	~OlaRide();
};

