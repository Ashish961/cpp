#include "pch.h"
#include "auto.h"


Auto::Auto()
{
}

void Auto::accept()
{
	char source[10], destination[10];
	int rate_per_km, distance;
	cout << "\nEnter Source : ";
	cin >> source;
	cout << "\nEnter Destination : ";
	cin >> destination;
	cout << "\nEnter rate per km : ";
	cin >> rate_per_km;
	cout << "\nEnter distance : ";
	cin >> distance;

	setSource(source);
	setDestination(destination);
	setRate_per_km(rate_per_km);
	setDistance(distance);

}

float Auto::calculateFare()
{
	
	
	return ((this->getDistance()*this->getRate_per_km()) + ((this->getDistance()*this->getRate_per_km())*0.15f));
}


Auto::~Auto()
{
}
