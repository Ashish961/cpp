#include "pch.h"
#include <iostream>

int main()
{
	int choice;
	Auto aa;
	Mini m;
	Prime p;
	char ch;
	do
	{
		cout << "\n1.Auto\n2.Mini\n3.Prime\n4.Exit";
		cout << "\nEnter your choice : ";
		cin >> choice;
		switch (choice)
		{
		case 1:
			aa.accept();
			cout << "\nTotal Fare : " << aa.calculateFare();
			break;
		case 2:
			m.accept();
			cout << "\nTotal Fare : " << m.calculateFare();
			break;
		case 3:
			p.accept();
			int fare = p.calculateFare();
			cout << "\nTotal Fare : " <<fare;
			break;
		case 4:
			return 0;
			break;
		default:cout << "\nEnter valid choice : ";
			break;
		}
		cout << "\nFor continue Press y and to stop press any key : ";
		cin >> ch;
	} while (ch == 'y');
}
