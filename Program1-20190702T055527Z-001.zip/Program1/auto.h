#pragma once
#include"pch.h"
class Auto : public OlaRide
{
public:
	Auto();
	void accept();
	float calculateFare();
	~Auto();
};

